# Start this lab: Choose context, roles and permissions

> [!IMPORTANT]
> This is a learner starter, not a completed solution. Use only synthetic data.
> Live Copilot, cloud and SDK steps require your own authorized access and are optional where the lesson says so.

| Item | Value |
| --- | --- |
| Lab | 01-interface |
| Track | hands-on |
| Runtime | VS Code |
| VS Code workspace | The extracted lab directory |
| Initial check | Expected to pass |
| Full instructions | [KIT-LESSON.md](KIT-LESSON.md) |
| Tools, personal accounts and optional cloud | [.workshop/PREREQUISITES.md](.workshop/PREREQUISITES.md) |
| Setup and GitHub walkthrough | [.workshop/SETUP.md](.workshop/SETUP.md) |

## 1. Extract and inspect

Extract into a new folder on your selected work drive. Open this file from the
extracted directory, not from the ZIP viewer. Do not merge it into another project.
The archive does not include credentials, installed runtimes, dependencies, Git
history or the instructor's reference directory.

Before running any downloaded code, review its source and use a trusted download.
With Node 24 available, run from the extracted lab directory:

```bash
node KIT-VERIFY.cjs
```

This checks the bundled file inventory. It does not authenticate the publisher,
scan for malware or prove that the exercise passes. After you edit files it is
normal for their baseline hashes to differ; use the lesson's tests for your work.

## 2. Record the baseline

Start in the extracted lab directory. The commands below state any additional
working-directory change explicitly:

```bash
node --test --test-concurrency=1 greeting.test.mjs
```

**Expected starting state:** The supplied baseline tests pass.

For the Python route, select the same interpreter in VS Code and your terminal;
on Windows, use `py` instead of `python` if that is the installed launcher.
Install only dependencies required by the selected exercise. Do not run every
project or profiler in parallel.

## 3. Open the correct workspace in your chosen client

Use **File > Open Folder** in a new VS Code window and select
this extracted lab directory.
VS Code Stable and Insiders are alternatives; configure the edition you use.
From the extracted kit root, open the workspace in Stable:

```bash
code .
```

Or open the same workspace in Insiders:

```bash
code-insiders .
```

For terminal-only work, install and authenticate the standalone Copilot CLI using
[the prerequisites guide](.workshop/PREREQUISITES.md). From the extracted kit root:

```bash
copilot
```

Use only one route. Investigate without edits, review a plan, approve a bounded
change, then inspect the diff and run the checks yourself in a separate terminal.

CLI work does not prove VS Code-specific controls, discovery or handoffs. Record
host-specific steps as not performed if you cannot use their documented host.
Follow [the full lesson](KIT-LESSON.md). When it says to work in a disposable copy,
this extracted kit is that copy. References to the curriculum describe its source,
not a second directory you must recreate.

Use the original README for project-specific details. The setup guide explains
local Git initialization and an optional private GitHub repository. Nothing is
published automatically. External documentation and other lessons still need an
internet connection; the local starter files do not depend on those links.

## 4. Prove completion and reset safely

- [ ] Record the initial command, working directory, exit code and observed result.
- [ ] Explain the concept and approved change before asking Agent to implement.
- [ ] Follow the positive and negative checks in the lesson; do not weaken tests.
- [ ] Review the actual diff and distinguish local tests from live integration.
- [ ] Save your evidence before stopping only the processes you started.
- [ ] For a fresh attempt, extract into another unused folder; do not overwrite your work.

See [the source lesson](https://github.com/workshop-gbb/awesome-copilot-adventures/blob/main/mslearn-github-copilot/Instructions/Labs/LAB_AK_01_examine_settings_interface.md) for updates. This package is a
snapshot; its file hashes are in [KIT-MANIFEST.json](KIT-MANIFEST.json).
