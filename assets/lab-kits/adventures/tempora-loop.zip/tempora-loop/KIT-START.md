# Start this lab: The Tempora Loop

> [!IMPORTANT]
> This is a learner starter, not a completed solution. Use only synthetic data.
> Live Copilot, cloud and SDK steps require your own authorized access and are optional where the lesson says so.

| Item | Value |
| --- | --- |
| Lab | tempora-loop |
| Track | adventures |
| Runtime | Node 24; live integrations are optional |
| VS Code workspace | The starter/ directory inside the extracted lab |
| Initial check | Expected intentional starter failure |
| Full instructions | [KIT-LESSON.md](KIT-LESSON.md) |
| Setup and GitHub walkthrough | [.workshop/SETUP.md](.workshop/SETUP.md) |

## 1. Extract and inspect

Extract into a new folder on your selected work drive. Open this file from the
extracted directory, not from the ZIP viewer. Do not merge it into another project.
The archive does not include credentials, installed runtimes, dependencies, Git
history or the instructor's reference directory.

Before running any downloaded code, review its source and use a trusted download.
With Node 24 available, run from the extracted lab directory:

```bash
node KIT-VERIFY.cjs
```

This checks the bundled file inventory. It does not authenticate the publisher,
scan for malware or prove that the exercise passes. After you edit files it is
normal for their baseline hashes to differ; use the lesson's tests for your work.

## 2. Record the baseline

Start in the extracted lab directory. The commands below state any additional
working-directory change explicitly:

```bash
node verify.js
```

**Expected starting state:** The verifier rejects the unfinished starter. Record its specific diagnostics before implementing the mission.

For the Python route, select the same interpreter in VS Code and your terminal;
on Windows, use `py` instead of `python` if that is the installed launcher.
Install only dependencies required by the selected exercise. Do not run every
project or profiler in parallel.

## 3. Open the correct workspace

Use **File > Open Folder** in a new VS Code window and select
the starter/ directory inside the extracted lab.
Follow [the full lesson](KIT-LESSON.md). When it says to work in a disposable copy,
this extracted kit is that copy. References to the curriculum describe its source,
not a second directory you must recreate.

Use the original README for project-specific details. The setup guide explains
local Git initialization and an optional private GitHub repository. Nothing is
published automatically. External documentation and other lessons still need an
internet connection; the local starter files do not depend on those links.

## 4. Prove completion and reset safely

- [ ] Record the initial command, working directory, exit code and observed result.
- [ ] Explain the concept and approved change before asking Agent to implement.
- [ ] Follow the positive and negative checks in the lesson; do not weaken tests.
- [ ] Review the actual diff and distinguish local tests from live integration.
- [ ] Save your evidence before stopping only the processes you started.
- [ ] For a fresh attempt, extract into another unused folder; do not overwrite your work.

See [the source lesson](https://github.com/workshop-gbb/awesome-copilot-adventures/blob/main/adventures/01-basics/tempora-loop/README.md) for updates. This package is a
snapshot; its file hashes are in [KIT-MANIFEST.json](KIT-MANIFEST.json).
