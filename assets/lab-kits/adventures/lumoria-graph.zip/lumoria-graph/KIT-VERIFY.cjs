'use strict';
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const manifest = JSON.parse(fs.readFileSync(path.join(__dirname, 'KIT-MANIFEST.json'), 'utf8'));
if (manifest.formatVersion !== 1 || !Array.isArray(manifest.files) || !manifest.files.length) {
  throw new Error('Invalid kit manifest.');
}
for (const entry of manifest.files) {
  if (typeof entry.path !== 'string' || !entry.path || /[\\:\u0000-\u001f]/.test(entry.path)
      || entry.path.split('/').some(part => !part || part === '.' || part === '..')) {
    throw new Error('Unsafe manifest path.');
  }
  let target = __dirname;
  for (const part of entry.path.split('/')) {
    target = path.join(target, part);
    if (fs.lstatSync(target).isSymbolicLink()) throw new Error('Unexpected symlink: ' + entry.path);
  }
  const bytes = fs.readFileSync(target);
  const digest = crypto.createHash('sha256').update(bytes).digest('hex');
  if (bytes.length !== entry.bytes || digest !== entry.sha256) {
    throw new Error('Kit file differs from its baseline: ' + entry.path);
  }
}
console.log('Verified ' + manifest.files.length + ' unchanged kit files. This is integrity evidence, not a lesson test.');
