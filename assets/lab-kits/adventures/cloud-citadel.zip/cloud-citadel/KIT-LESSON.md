
# The Cloud Citadel


> [!NOTE]
> **Status:** Content ready · **Media:** Generated cover and original SVG illustration · **Last verified:** 2026-09-05  
> **Primary capability:** Delegating work to GitHub Copilot cloud agent

![An engineer inspects a task package and map in a local workshop linked to a distant cloud citadel.](.workshop/media/6ab29fcb29795842.webp)

<details>
<summary>Original concept illustration (SVG)</summary>

![Bounded issue, Remote work, Human review illustrated through The Cloud Citadel.](.workshop/media/ff3a4a77df1fbfe2.svg)

</details>

> [!TIP]
> [Download this learner kit](https://github.com/workshop-gbb/awesome-copilot-adventures/blob/main/assets/lab-kits/adventures/cloud-citadel.zip) and use
> [the extraction and setup guide](.workshop/SETUP.md). Keep the original starter untouched.

```mermaid
---
config:
  theme: base
  look: classic
  themeVariables:
    darkMode: false
    background: "#ffffff"
    primaryColor: "#f5f5f5"
    primaryTextColor: "#111111"
    primaryBorderColor: "#555555"
    secondaryColor: "#e0e0e0"
    secondaryTextColor: "#111111"
    secondaryBorderColor: "#666666"
    tertiaryColor: "#bdbdbd"
    tertiaryTextColor: "#111111"
    tertiaryBorderColor: "#444444"
    lineColor: "#444444"
    textColor: "#111111"
    mainBkg: "#f5f5f5"
    nodeBorder: "#555555"
    clusterBkg: "#ffffff"
    clusterBorder: "#999999"
    edgeLabelBackground: "#ffffff"
    actorBkg: "#e0e0e0"
    actorBorder: "#555555"
    actorTextColor: "#111111"
    actorLineColor: "#777777"
    signalColor: "#333333"
    signalTextColor: "#111111"
    labelBoxBkgColor: "#f5f5f5"
    labelBoxBorderColor: "#777777"
    labelTextColor: "#111111"
    loopTextColor: "#111111"
    activationBkgColor: "#bdbdbd"
    activationBorderColor: "#555555"
    noteBkgColor: "#f5f5f5"
    noteTextColor: "#111111"
    noteBorderColor: "#777777"
    attributeBackgroundColorOdd: "#f5f5f5"
    attributeBackgroundColorEven: "#e0e0e0"
---
flowchart LR
    accTitle: The Cloud Citadel capability map
    accDescr: The local kit prepares the contract. It cannot establish cloud availability or prove an implementation ran remotely.
    I["Issue and acceptance"] --> P["Paths and authority review"]
    P --> C["Authorized cloud session"]
    C --> D["Diff, logs and checks"]
    D --> H{"Maintainer accepts?"}
    H -->|No| I
    H -->|Yes| E["Recorded decision"]
```

**Legend.** The cloud stage is optional live execution; the decision diamond remains a human review boundary.

**Explanation.** The local kit prepares the contract. It cannot establish cloud availability or prove an implementation ran remotely.

## Official references

These official sources are the authority for product behavior and availability. Recheck them when using a different surface or after a product update.

- [About GitHub Copilot cloud agent](https://docs.github.com/en/copilot/concepts/agents/cloud-agent/about-cloud-agent)
- [Start cloud agent sessions](https://docs.github.com/en/copilot/how-tos/use-copilot-agents/cloud-agent/start-copilot-sessions)
- [Cloud agent risks and mitigations](https://docs.github.com/en/copilot/concepts/agents/cloud-agent/risks-and-mitigations)

## Story

The Cloud Citadel grants an agent an ephemeral workshop. A safe quest arrives with scope, acceptance criteria, and a path for human review.

The fantasy is a memory aid; the engineering lesson requires observable, reproducible evidence.

## Learning objectives

- Write an issue-sized task with allowed paths, non-goals and a verification command.
- Distinguish validating a local task contract from executing a cloud agent.
- Define the logs, diff and checks a maintainer needs before accepting a remote result.

## Prerequisites

For tools and personal accounts, complete [the prerequisites guide](.workshop/PREREQUISITES.md).
For terminal-only study, follow [the extracted-kit CLI route](.workshop/SETUP.md#use-copilot-cli-from-the-extracted-kit);
VS Code-specific evidence remains separate.

| Requirement | Why it matters |
| --- | --- |
| Complete the preceding adventure, or demonstrate its exit evidence | Keep this mission focused on its named capability |
| Node 24 and the extracted kit | The local verifier uses the supplied runtime and files |
| A disposable folder outside another project | Customizations and intentional failures must not leak into other work |
| Authorized host access, only for live steps | Availability, tools and policies differ |

**Evidence boundary:** The verifier does not execute node test/run.js or assign a real issue. A live exercise needs a repository with that actual command and separate authorization.

Estimated session: 45–75 minutes after prerequisites; actual duration varies. Never use production secrets or customer data.

## Concept explanation

GitHub Copilot cloud agent can work on assigned repository tasks in a GitHub-hosted environment and propose changes through a pull request. Eligibility, policy, model access, tools, network access, and feature availability vary. Humans remain responsible for task definition and review. The issue is an executable contract and must not contain secrets.

### Concrete use case

A cloud worker receives a small issue with source scope and acceptance criteria. A command written in JSON is only a proposed check until an authorized worker actually runs it.

### Vocabulary checkpoint

- **Role:** Ask, Plan, Agent, or a custom agent.
- **Harness/surface:** the runtime or product surface in which a role operates.
- **Target:** the selected session destination, such as Local, Copilot, or Cloud where exposed.
- **Environment:** the folder, worktree, local machine, Codespace, or remote environment.
- **Instructions:** automatically applied durable context.
- **Prompt:** a manually invoked task template.
- **Skill:** reusable expertise loaded when relevant.
- **Custom agent:** a role with instructions, tools, and optional handoffs.
- **MCP:** Model Context Protocol.
- **Evidence:** a path, diff, command result, trace, or review decision.

## Ask → Plan → Agent workflow

### Ask — investigate

1. Identify the real user outcome and current source of truth.
2. Inspect relevant files, instructions, tools, permissions, and existing checks.
3. Cite concrete paths or platform evidence for every important finding.
4. Record uncertainty and do not infer unavailable capabilities.

**Gate:** No implementation until the current state and evidence are understood.

### Plan — design

1. State scope, non-goals, assumptions, risks, and trust boundaries.
2. Select the minimum role, tools, authority, and environment.
3. Define acceptance criteria, verification commands, review, and reset.
4. Mark any Preview or experimental dependency and provide a fallback.

**Gate:** Another learner should be able to predict completion from the plan.

### Agent — execute

1. Make the smallest reversible change or produce the planned artifact.
2. Use short inspect → change → verify loops.
3. Preserve command output, exit status, diffs, traces, or platform records.
4. Stop when acceptance criteria are met; do not perform unrelated cleanup.

### Review — challenge

1. Inspect the complete diff or artifact.
2. Compare each result with the plan and acceptance criteria.
3. Run the narrowest relevant existing check, broadening only when justified.
4. Record limitations and unresolved risks.
5. Score the work with [rubric.md](.workshop/RUBRIC.md).

## Guided mission

### 1. Prepare one isolated copy

1. Download and extract the [cloud-citadel kit](https://github.com/workshop-gbb/awesome-copilot-adventures/blob/main/assets/lab-kits/adventures/cloud-citadel.zip) into a new work-drive directory.
2. Read `KIT-START.md` at its root. Open `starter/` as the VS Code workspace when testing discovery, but run the verifier from the kit root.
3. Inspect `starter/task-contract.json`, `verify.js` before editing.
4. From the extracted kit root, run `node verify.js`.
5. Record the documented starter rejection. A missing runtime or unrelated crash is not the expected exercise result.

### 2. Investigate and plan

Copyable baseline command, from the extracted kit root:

```bash
node verify.js
```

In Ask, request a trace of the inspected files and what the verifier actually observes. Challenge any claim about live execution that is not supported by output.

Use this planning prompt:

```text
Complete the goal, allowedPaths, acceptanceCriteria, local verification command and required evidence. Keep networkRequired false and add no credentials or deployment instructions.
Do not implement yet. Identify affected files, the negative case and a safe reset.
```

### 3. Implement the reviewed slice

1. Approve only the named starter artifact and necessary focused tests.
2. Ask Agent to implement one slice; inspect proposed commands before execution.
3. Run `node verify.js` again from the kit root, or `node ../verify.js` from `starter/`.
4. Compare the exact result with the checkpoint below and review the complete diff.
5. Record host discovery or live activity separately when available. Do not enable extra services to manufacture a passing result.

> [!IMPORTANT]
> **Checkpoint:** The task names the exact two allowed directories and the evidence a reviewer will demand.
> The verifier does not execute node test/run.js or assign a real issue. A live exercise needs a repository with that actual command and separate authorization.

### 4. Prove a check can reject a mistake

Set networkRequired true in the copied contract and confirm rejection. Restore the bounded local contract.

| Observation | Decision | Action | Evidence | Limitation |
| --- | --- | --- | --- | --- |
| Initial state and exact diagnostic | Why this change is needed | Named file and bounded change | Command, exit code and observed result | What the local check does not prove |

Finish with the adventure-specific capability evidence in [the rubric](.workshop/RUBRIC.md), not just the presence of a file.

## Intentional failure: The Empty Royal Decree

Perform this only in a disposable environment:

Draft only “improve the project.” Completion cannot be determined because product intent, risk tolerance, and non-goals are missing.

### Recovery

Return to Ask, identify the violated boundary, narrow the plan, remove unnecessary authority or context, and repeat the smallest relevant verification. Document the causal lesson rather than merely stating that the attempt failed.

## Independent challenge

Prepare an issue that changes code and documentation while forbidding deployment, dependency upgrades, and unrelated cleanup.

Constraints:

- Do not copy the guided mission verbatim.
- Do not add tools, permissions, or cloud resources without a stated need.
- Do not claim quality, performance, compatibility, or availability without executed evidence.
- Keep fantasy language subordinate to technical clarity.

## Evidence checklist

- [ ] Source-grounded Ask findings.
- [ ] Approved plan with scope, non-goals, risks, checks, and reset.
- [ ] Agent diff or artifact limited to the declared scope.
- [ ] Verification output with command, status, or platform record.
- [ ] Intentional-failure root cause and recovery.
- [ ] Independent challenge result.
- [ ] Explicit limitations and feature-status notes.
- [ ] Completed [rubric.md](.workshop/RUBRIC.md).

## Reset instructions

1. Save your diff, command output and limitations from the disposable kit.
2. Stop only the process or learning session you started. Do not stop other projects.
3. If you initialized Git in the kit, inspect `git status --short` there and restore only your named exercise files from its local baseline.
4. Otherwise, extract the original ZIP into a new unused directory for another attempt; do not overwrite your current work.
5. Remove only exercise-owned configurations, worktrees or remote resources after reviewing anything worth preserving.

The curriculum source and other projects must remain unchanged. A reset of the copied kit is not a repository-wide hard reset.

## Next adventure

[The Terminal Gate](https://github.com/workshop-gbb/awesome-copilot-adventures/blob/main/adventures/04-surfaces/terminal-gate/README.md)
