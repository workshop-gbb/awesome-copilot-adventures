---
name: ms-presentation-deck
description: "Gera o deck HTML no padrão paulasilva-ms (Microsoft 4-color, Inter + JetBrains Mono): um deck HTML trilíngue para apresentador, com painel de speaker notes e presenter view, que é o entregável principal e a fonte da verdade. Use SEMPRE que a Paula pedir um deck, apresentação, slides, briefing, talk, ou material visual para audiência, e também para \"atualizar o deck\" e para os derivados quando pedidos."
---

# ms-presentation-deck (v3.1.0)

Engine de apresentação para a Paula Silva (Developer Solutions Advisor, Software Latam Leader ·
Data & AI, Global Black Belt at Microsoft Americas). O entregável é **o deck HTML trilíngue com
speaker notes e presenter view**, único arquivo gerado por padrão. Derivados (público, PDF, PPTX)
só quando pedidos.

## What's new in v3.1.0 (2026-09-04)

Oito defeitos que a Paula achou a olho no deck Hooks Lifecycle, cada um corrigido **no kit ou num
gate**, nunca no slide. `references/changelog.md` tem o raciocínio completo de cada um.

| Change | Detail |
|---|---|
| **Um sistema de numerais só** | A agenda usa as MESMAS barras do divider, em escala de linha (`roman_bars.roman_inline`, 34px; 28px em `agenda--5`). Numeral em JetBrains Mono na agenda está proibido: a linha da agenda é a promessa que o divider cumpre, e as duas têm que parecer o mesmo objeto. |
| **Zona é dona da própria faixa de rótulo** | `Diagram.LABEL_BAND = 30`: nenhum nó começa dentro dos 30px de topo de uma zona. `render()` avisa no build; `audit_svg.py` reprova rótulo de zona sobre card de nó. |
| **Rótulo centralizado não sai da moldura** | `audit_svg.py` OVERFLOW mede o escape dos dois lados. `scenes_kit.PILL` cresce para caber o texto em vez de aceitar largura fixa. |
| **Caixa com moldura não esconde o próprio conteúdo** | `qa_deck.py` reprova `clip`: `scrollHeight` maior que a altura útil em qualquer caixa com borda ou fundo de papel. |
| **A marca do produto não quebra kicker** | `decorateProductNames()` pula elemento em caixa alta com até 34 caracteres. Kicker é uma unidade tipográfica. |
| **Sequência é forma de diagrama** | Dois atores com dialetos diferentes é `Diagram.lifeline` / `activation` / `message` / `selfmsg`, lido de cima para baixo, nunca abas com parágrafo dentro. Retorno é tracejado (`message(..., dashed=True)`). |
| **Interativo responde com mecanismo** | `C.chainsim`: a chamada percorre uma cadeia visível de controles, o que barrou acende na cor dele, o que a política não tem fica tracejado, e o veredito vem com o motivo. Picker com barra abstrata não é simulação. |
| **`window.I18N` publicado** | O esqueleto precisa de `window.I18N = I18N;`. Sem isso, `tr()` e `retranslate()` caem no inglês e todo interativo vira monolíngue ao sair e reentrar no slide. |
| **Gates veem o fim da animação** | `shots.py` espera 4200ms. Cena cujo último beat cai depois disso tem beat morto: encurte a cena. |
| **Nó que barra parece que barra** | `kind='block'` + `color=` (`.dg .n--block`). Sem isso a legenda nomeia uma distinção que o diagrama não desenha. |
| **Slide Sobre é opcional** | Só quando a sala não sabe quem está falando. Num workshop que ela conduz, a atribuição fica na linha de contato do fechamento. |

## What's new in v3.0.0 (2026-09-04)

O deck GitHub Copilot Hooks Lifecycle v4.0.4 e o showcase master de 109 slides fixaram o padrão
visual, e a skill passou a **gerar** decks em vez de clonar HTML. Tudo abaixo é regra.

| Change | Detail |
|---|---|
| **Deck gerado, nunca escrito à mão** | `scripts/deck_builder.py` (`Deck`) monta cover, sobre, agenda, dividers, conteúdo e fechamento sobre o esqueleto `assets/template_skeleton_multi.html` e anexa todas as camadas (sprite, visual layer, famílias, fundo de código, numerais em barras, links, cenas, runtime, fill, tipografia). Um deck que não passou pelo builder está fora do padrão. |
| **Canvas cheio, sempre** | `fill_canvas.js` cresce tipo, padding, gaps e margens de cada slide de conteúdo até tocar o palco (até 1.85x) e encolhe quando não cabe (até 0.84x). Slide curto é erro de conteúdo, não de fonte. Mocks e código crescem no máximo 1.18x. |
| **Fundo de código no lugar do glow** | Cada slide de conteúdo recebe um bloco tênue (10%) de fragmentos de algoritmo, shell, JSON, Pascal, SQL e caixas ASCII no canto superior direito, sumindo na diagonal (`codebg.deco`). Nunca a bola gradiente, nunca marca d'água de numeral romano. |
| **Divider: barras, título em uma linha, subtítulo** | O numeral é desenhado como barras limpas (`roman_bars`), sem serifa nem travessa; o título tem 60px e cabe em UMA linha em qualquer idioma (encolhe até 41px); subtítulo em até duas linhas. Nada mais. |
| **Sem órfãs, sem quebra perdida** | `typo.py`: palavras de função (o, a, de, um, the, and, los, del…) coladas à seguinte, últimas duas palavras coladas, `text-wrap: balance` em títulos e `pretty` em texto. As cadeias de NBSP antigas são removidas no build. `audit_typo.py` acusa qualquer título ou subtítulo com mais de duas linhas, última linha de uma palavra ou linha terminando em palavra de função. |
| **Cargo e fechamento** | Linhas exatas: `Developer Solutions Advisor, Software Latam Leader` e `Data & AI, Global Black Belt at Microsoft Americas`. Fechamento sem bloco de "próximo passo": contato à esquerda, code-block de regra rápida à direita. |
| **Links em nova aba** | Todo `http` é hyperlink visível (azul, sublinhado, mono) com `target="_blank" rel="noopener"`; o builder aplica em todo `<a>`. |
| **Showcase master de 109 slides** | `assets/showcase_master_multi.html`: um slide por padrão em nove partes (texto, tabelas, gráficos, todos os diagramas de engenharia, arquiteturas com ícones oficiais, cenas animadas, simulações de produto em tema claro, interativos, mídia e código). É a referência visual e a prova de que o kit gera tudo. |
| **Kit completo** | `components.py` (45 componentes), `charts.py` (11 gráficos), `diagram_kit.py` + `showcase_diagrams.py` (18 tipos de diagrama + 8 arquiteturas), `scenes_kit.py` (8 cenas), `mocks.py` (terminal digitado, VS Code claro, GitHub Copilot Chat, portal do Azure, pull request, navegador, celular), `runtime.js` (interativos e markdown), `visual_layer.py` (50 ícones de linha + CSS), `visual_ext.py` (CSS das famílias). |
| **QA nova** | `qa_deck.py` (overflow nas 3 línguas, animações desligadas inclusive pseudo-elementos), `audit_typo.py`, `diag_fill.py`, `shots.py` (contact sheets), `census.py`, `audit.py`. Zero falhas antes de entregar. |

O histórico das regras v2.0.0 a v2.6.0 está em `references/changelog.md`.

## When to use

"Quero um deck sobre X", "apresentação executiva", "briefing técnico", "slides para uma talk",
"atualizar o deck", "exportar pra PPTX", "versão pública". Não usar para documentos longos,
diagramas avulsos, Gamma ou Canva.

## The deliverable

| Default | File | What |
|---|---|---|
| ⭐ sempre | `<TopicCamelCase>_v<M>_<m>_<p>_<YYYYMMDD>_multi.html` | trilíngue (en, pt-BR, es), notas (N), presenter (F), offline, fontes embutidas |
| a pedido | `_<locale>_public.html` (`make_public.py`), `.pdf` (`make_pdf.py`), `.pptx` (`references/pptx-mapping.md`) | derivados |

Versionamento: patch = texto de um slide; minor = slide novo ou layout; major = estrutura.

## Workflow

1. **Fatos primeiro.** Todo slide que nomeia capacidade de produto sai da documentação oficial do
   dia (learn.microsoft.com, docs.github.com, code.visualstudio.com). Nunca inventar campo de config.
2. **Ler `references/visual-standard.md`** (o padrão) e abrir `assets/showcase_master_multi.html`
   para escolher a forma de cada slide. Depois `components.md`, `charts.md`, `diagrams.md`,
   `scenes.md`, `simulations.md`, `interactives.md` conforme o que o conteúdo pede.
3. **Planejar**: lista de slides com uma linha cada e o mapa slide → componente. Um componente por
   slide; um herói (cena, simulação ou interativo) por parte; toda arquitetura é diagrama; nenhum
   arquétipo acima de 25% do deck.
4. **Escrever o script do deck** (`build_<topic>.py`) com o `Deck`: cover (duas frases, a segunda
   azul), `who()` **só quando a sala não sabe quem está falando** (deck enviado antes, público interno
   amplo, material que vai circular sem ela; num workshop que ela mesma conduz, o slide de bio gasta o
   primeiro minuto com a apresentadora em vez do assunto, e a atribuição fica na linha de contato do
   fechamento), "leia antes" quando for workshop, `agenda()`, `part()` + `content()` por parte,
   `closing()`. Strings de chrome, títulos, legendas e
   notas nas três línguas por `reg`/tuplas; corpos técnicos em inglês. Notas por slide seguindo
   `references/speaker-notes.md` (`Deck.N` para a forma curta).
5. **Gerar e validar** (um job por vez, fontes reais):

```bash
python build_<topic>.py                                   # escreve o _multi.html
python scripts/qa_deck.py deck.html                       # 0 bad em en, pt-BR, es; errors []
python scripts/audit_typo.py deck.html pt-BR,es,en        # só o fechamento (duas linhas intencionais)
python scripts/diag_fill.py deck.html en                  # sem "shrunk"; "short" só em slides nofill
python scripts/shots.py deck.html pt-BR shots/            # olhar TODAS as contact sheets
python scripts/audit.py deck.html                         # identidade: em dashes, GitHub Copilot, e-mail, tokens
python scripts/census.py deck.html                        # nenhum arquétipo acima de 25%
```

6. **Olhar as contact sheets** no estado final da animação: sobreposição, seta sobre texto, rótulo
   comprimido, slide vazio embaixo, título em duas linhas no divider, tudo é defeito. Corrigir no
   script, gerar de novo, medir de novo.
7. **Entregar o HTML** e parar. Uma linha: público, PDF e PPTX podem ser gerados quando pedidos.
   `.zip` da skill só depois da aprovação visual da Paula.

## The standard in one screen (details in `references/visual-standard.md`)

- Palco 1280x720; conteúdo em 1160px úteis; nada cruza 1240 ou 720.
- Capa: duas frases, Inter Medium 500, 82px, a segunda em azul, nada mais. Slide 2: Sobre com foto.
  Agenda gerada e clicável. Divider: barras + título em uma linha + subtítulo. Fechamento sem
  próximo passo. Fundo de código em todo slide de conteúdo; claro e escuro com os mesmos dois
  fundos.
- Tipografia: título de conteúdo 32px em uma linha quando couber (nunca três); sem órfãs; sem
  em dash; "GitHub Copilot" sempre completo; nomes de produto com a marca oficial.
- Cor como código: um accent por parte; vermelho sintoma/nega, verde correção/passa, amarelo
  decisão/loop, azul plataforma.
- Um componente por slide, um herói por parte, toda arquitetura em diagrama com ícone oficial no nó.
- Mocks em tema claro (terminal é a única superfície escura); interativos sem spoiler; markdown
  renderizado ao vivo; links em nova aba; mídia com fonte.

## Identity rules (NON-NEGOTIABLE)

- **Sem em dash (—)** em lugar nenhum. Vírgula, ponto, dois-pontos ou " · ".
- **"GitHub Copilot"** sempre por extenso.
- **Cargo**: `Developer Solutions Advisor, Software Latam Leader` / `Data & AI, Global Black Belt at Microsoft Americas`.
- **Contato**: só `paulasilva@microsoft.com`. Nunca `@paulasilvatech`, LinkedIn ou GitHub pessoal em deck Microsoft.
- **Paleta**: `#F25022` red, `#7FBA00` green, `#FFB900` yellow, `#00A4EF` blue, tokens `--ps-*`.
- **Fontes**: Inter e JetBrains Mono embutidas em base64 (PPTX usa Segoe e Cascadia Mono).
- **Marca**: um `.deck-brand` fixo com o 4-square Microsoft, favicon idem. Autora: Paula Silva.

## Scripts

| Script | Papel |
|---|---|
| `deck_builder.py` | `Deck`: cover, who, agenda, part, content, closing, write. Aplica todas as camadas. |
| `components.py`, `charts.py`, `mocks.py` | corpos de slide (texto, tabelas, interativos, mídia; gráficos; simulações) |
| `diagram_kit.py`, `showcase_diagrams.py` | diagramas e arquiteturas; os 26 do showcase são os templates |
| `scenes_kit.py` | oito cenas animadas com legendas e notas trilíngues; primitivas `T R G ICON PILL` |
| `visual_layer.py`, `visual_ext.py`, `codebg.py`, `roman_bars.py`, `typo.py`, `fill_canvas.js`, `runtime.js` | as camadas que o builder anexa |
| `showcase_build.py` | gera `assets/showcase_master_multi.html`; é o exemplo completo de script de deck |
| `qa_deck.py`, `audit_typo.py`, `diag_fill.py`, `shots.py`, `census.py`, `audit.py`, `audit_arrows.py`, `audit_orphans.py`, `qa_overflow.py` | QA |
| `make_public.py`, `make_pdf.py`, `capture.py`, `make_pptx.js` | derivados a pedido |

## Bundled assets

- `assets/showcase_master_multi.html` ⭐ o catálogo master (109 slides, 45 arquétipos, 3 línguas).
- `assets/example_deck_hooks_lifecycle_multi.html` ⭐ GitHub Copilot Hooks Lifecycle v5.1.0, 70 slides: o deck de referência do padrão (workshop técnico, 8 partes, 8 cenas, 25 arquétipos, diagrama de sequência, chainsim, sem slide Sobre).
- `assets/example_deck_btg_multi.html` a referência de repertório visual e da capa.
- `assets/template_skeleton_multi.html` o engine puro (`<!--SLIDES-->`, `/*I18N*/{}`), `assets/who_slide_snippet.html` o slide Sobre com a foto, `assets/brand_sprite.html` marcas extras, `assets/paulasilva-logo.png` (canal pessoal apenas).

## Critical lessons learned

1. `reduced_motion='no-preference'` no Playwright; medir com `.ps-measure` (animações e pseudo-elementos desligados), senão anel pulsante e transform de entrada viram overflow falso.
2. Nome de classe novo colide com o engine: `.tier`, `.bars`, `.quote`, `.pcard`, `.step`, `.no` já existem; por isso as famílias têm prefixo (`ptier`, `pbars`, `bquote`, `azcard`). `grep` antes de criar.
3. `f-string` com barra invertida na expressão quebra em Python 3.11: montar o atributo fora da f-string.
4. NBSP em cadeia nos títulos produz "Faça o / agente terminar o trabalho.": o build normaliza e o runtime cola só palavra de função e o último par.
5. `overflow-wrap: normal` global evita quebra no meio da palavra, mas URLs e ids de ícone precisam de `.brk`/`.lku` para quebrar em qualquer ponto.
6. Rótulo de gantt maior que a barra vai para fora da barra (o builder decide em build time); legenda do radar quebra em linhas de três; cabeçalho de lifeline cresce com o texto e o ícone fica à esquerda.
7. Agenda com nove ou dez partes usa cinco linhas (`agenda--5`); o grid do engine tem quatro linhas por coluna.
8. Texto de SVG nunca quebra: rótulos curtos, legendas em HTML.
9. `transform` de keyframe anula o `transform` do SVG: grupo externo com translate, interno animado.
10. Inserir slide é permutação: o builder re-chaveia notas e agenda a partir da ordem final; nunca editar `sN` à mão.
11. Um job de QA por vez; screenshots só depois de a animação assentar (2.6 s; mais para terminais longos).
12. Slide curto no `diag_fill` com K 1.84 e bottom < 640: falta conteúdo (bloco `.why`, `watch`, segundo componente), não falta fonte.
