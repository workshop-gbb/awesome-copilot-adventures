# Diagrams and architectures (v3.0.0)

Any slide that explains an architecture, a flow, a sequence, a data model, identity, a network, a
pipeline, a decision or "where does X run" is an inline SVG built with `scripts/diagram_kit.py`.
Never a table of chips or text boxes. Every diagram type engineering uses has a working template in
`scripts/showcase_diagrams.py` (parts IV and V of the showcase); copy the closest one and change
the content, keeping the coordinates discipline.

## The kit

```python
from diagram_kit import Diagram, COLORS
from showcase_diagrams import az, gh, li            # icon helpers: az('ic-aca'), gh('gh-copilot'), li('lock', color)

d = Diagram('dg7', 1120, 460)                         # id must be unique in the deck; canvas is 1120 x 460 (scaled to the slide width)
d.zone(x, y, w, h, 'blue', 'Region · Brazil South')   # dashed tinted box with a mono uppercase label
d.lane(x, y, w, h, 'green', 'Developer', vertical=False)   # swimlane
d.node(x, y, w, h, 'Label', 'sub line', icon=az('ic-apim'), kind='paper'|'soft'|'dark'|'ghost', bar='red', color='blue', sub2='')
d.pill(x, y, w, 'orders.created', 'blue')              # rounded chip inside a node or a bus
d.diamond(cx, cy, w, h, 'valid?', 'schema + auth')    # decision
d.cylinder(cx, cy, w, h, 'Azure SQL', 'geo-replica')  # database
d.actor(cx, cy, 'Developer')                          # stick figure (C4 person)
d.note(x, y, w, h, ['line 1', 'line 2'])              # yellow folded note
d.entity(x, y, w, 'Order', [('order_id', 'pk'), ('customer_id', 'fk'), ('status', '')])   # ER entity
d.classbox(x, y, w, 'Hook', ['+ event: HookEvent'], ['+ run(payload): Decision'], stereo='abstract')
d.state(cx, cy, w, 'In review', 'reviewers assigned', kind='paper'|'soft'|'dark'); d.startstop(cx, cy, end=False)
d.lifeline(x, y_top, y_bottom, 'GitHub Copilot CLI', icon=gh('gh-cli')); d.activation(x, y0, y1)
d.message(x0, x1, y, 'stdin: {…}', kind='acc', marker='ar-acc', dashed=False); d.selfmsg(x, y, 'parse twice')
d.conn([(x0, y0), (x1, y1), …], kind='thin'|'acc'|'fat'|'dashed'|'out'|'never'|'gov'|'red'|'green'|'blue'|'yellow', marker='ar'|'ar-acc'|'ar-red'|'ar-green'|'ar-blue'|'ar-yellow'|'ar-ink'|'none'|'dot'|'crow'|'tri'|'dia')
d.curve(x0, y0, x1, y1, kind, marker, bend=0.5)
d.label(x, y, 'https', anchor='middle', color='blue')   # label text with a paper halo, placed OFF the line
d.text(x, y, 'free text', cls='cl', anchor='start')
d.dot([(x, y), …], dur=5, begin=2.4)                  # one traveling dot on an invisible track (SMIL)
d.legend(y, [('sw', 'blue', 'compute'), ('ln', 'accent', 'request'), ('dl', 'ink3', 'reply')])   # sw = swatch, ln = line, dl = dashed
html = d.render()
```

Every element gets an entrance order automatically (`--d`): zones and nodes fade up in sequence,
solid connectors draw, dashed ones fade, the dot travels last. Dark slides need no extra rule: all
fills and strokes are tokens.

## Craft rules (the QA checks the first three)

1. **Labels off the line**: a connector label sits 7px above a horizontal segment or 8px to the
   right of a vertical one, with the paper halo (`cl--free`). `audit_arrows.py` flags a connector
   crossing a `<text>` box.
2. **Nothing crosses a node**: route orthogonal connectors through the gaps between zones
   (`conn([(a), (corner), (corner), (b)])`), never through a cylinder or a box. The class diagram
   and deployment templates show the detour.
3. **Text never compresses**: node labels are short (two or three words); the node is wide. Node
   header boxes in sequence diagrams grow with the label and put the icon to the left of the text.
   `fitDiagramText()` is the safety net for the third language, not the plan.
4. **Icons inside the nodes**: every product carries its official mark (`#ic-*` Azure, `#gh-*` and
   `#gx-*` GitHub, `#br-*` brands) and every concept a line icon (`#i-*`). Never a redrawn logo.
5. **One legend per diagram**, at y = H + 2 (`d.legend(462, …)` on a 460 canvas).
6. **Color is the code**: zones tinted by role (blue compute, green data, yellow edge and identity,
   red governance), connectors by meaning (accent = the request path, red = deny, green = pass,
   dashed = config, telemetry or exceptional).
7. Canvas 1120 x 460 fills the slide width; use the full height (the request-path template is the
   only flat one and it carries a bar row underneath to fill the stage).

## The catalog (part IV of the showcase, `showcase_diagrams.py`)

| Type | Function | When |
|---|---|---|
| Flowchart | `flowchart()` | decisions as diamonds, outcomes as colored nodes |
| Sequence | `sequence()` | who calls whom, in order, with payloads (lifelines, activations, notes) |
| State machine | `state_machine()` | states as pills, transitions as labeled arrows, start and end marks |
| Entity relationship | `er_diagram()` | entities with pk / fk rows, crow feet on the many side |
| Class | `class_diagram()` | inheritance (tri), aggregation (dia), dependency (dashed) |
| C4 context | `c4_context()` | people, the system in scope, external systems |
| C4 container | `c4_container()` | processes, stores and calls inside the system |
| Deployment | `deployment()` | region, node pools, data and edge as nested zones |
| Event-driven | `event_driven()` | publisher, topics on a bus, consumers |
| Data pipeline | `data_pipeline()` | ingest, land, clean, model, serve with governance across |
| Hexagonal | `hexagonal()` | ports and adapters around a core |
| Request path | `request_path()` | hops with latency, budget bars underneath |
| Decision tree | `decision_tree()` | two questions, four leaves |
| Mind map | `mind_map()` | one idea, four branches, three leaves each |
| Swimlane | `swimlane()` | three lanes, one process, hand-offs visible |
| Network | `network()` | VNet, subnets, private endpoints |
| DAG | `dag()` | topological order and the critical path in red |
| Git branching | `git_branching()` | main, release, feature and hotfix rails with tags |

## Reference architectures (part V, official icons)

`arch_webapp()` (Front Door, App Service, Functions, SQL, Key Vault, Monitor), `arch_aks()` (API
Management, three services, bus, cache, Prometheus, ACR), `arch_data()` (sources, lakehouse with
ADLS, Databricks, Purview, consumers), `arch_foundry()` (Agent Service, models, tools, search,
safety, Entra Agent ID), `arch_copilot()` (GitHub Copilot, cloud agent, hooks, Actions, security,
enterprise policies), `arch_devops()` (code, build, scan, package, deploy, observe with gates),
`arch_zerotrust()` (signals, policy decision, protected resources), `arch_hubspoke()` (hub VNet
with firewall, VPN, Bastion, DNS; production and dev spokes).

## Hotspots on a diagram

`C.hotspots(d.render(), [(x_pct, y_pct, title, text, color)])` puts numbered points on any
diagram; a click reveals the tooltip (showcase VIII · 96).

## Zones own their label band

Every zone keeps its top 30px (`Diagram.LABEL_BAND`) for its own label. A node placed inside that
band collides with the label as soon as a longer language stretches it, which is the first defect an
audience sees. `Diagram.render()` prints a build-time WARN naming the node and the zone, and
`audit_svg.py` TOUCH fails a `zl` or `lanel` label that lands on a node rectangle. A band that is
only 74px tall has no room for both: make the zone taller, not the label smaller.

## Sequence diagrams

Two actors speaking slightly different dialects is a sequence diagram, never a tab strip:

```python
d.lifeline(x, y0, y1, 'VS Code · JetBrains', icon=None)   # header box grows with the label
d.activation(x, y0, y1)                                   # the actor is busy between these rows
d.message(x0, x1, y, 'preToolUse -> PreToolUse', 'red', 'ar-red')
d.message(x1, x0, y, 'exit 0 + {}', dashed=True)          # a return is dashed
d.selfmsg(x, y, 'both name sets')                         # a decision the actor takes alone
```

Rules: one message per row, 38 to 42px pitch, the payload named on the arrow (not "response"), returns
dashed, and the self-message label short enough not to reach the next lifeline. `dashed=True` switches
to the `.c--dashed` family because the draw animation owns `stroke-dasharray`.

## Nodes that can stop the flow

`kind='block'` plus `color=` tints and outlines the node in its own colour (`.dg .n--block`), so a
legend entry like "can block" has something to point at. Without it, a legend swatch names a
distinction the diagram never draws.
