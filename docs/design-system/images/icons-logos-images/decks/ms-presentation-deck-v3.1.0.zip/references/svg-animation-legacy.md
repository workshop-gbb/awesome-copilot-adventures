# Animated SVG scenes (v2.2.2)

The recipe behind the iceberg scene in `assets/example_deck_btg_multi.html` (slide 8). No library, no
JavaScript, no GIF: inline SVG with CSS keyframes, driven by the engine's own `data-active` flag.

## Why this approach

| Choice | Reason |
|---|---|
| Inline SVG, not an image | Text and colours come from CSS variables and i18n, so the scene translates and re-themes for free |
| CSS keyframes, not SMIL | SMIL is deprecated in some engines; CSS animates `transform` and `opacity` on the compositor and stays smooth on a projector |
| No JS | The engine already toggles `data-active` per slide, which is the only trigger needed |
| Text in an HTML overlay | **SVG `<text>` does not wrap.** Any label longer than a few words must live in an absolutely positioned HTML layer above the SVG, or it will spill outside its panel in the longest locale |

## The pattern

```
.scene            position: relative           ← anchor for HTML overlays
.scene__svg       width 100%, max-width, block ← the drawing only
.scene__panel     position: absolute; left/top in %   ← HTML text that wraps
```

Every animated element starts in its rest-but-hidden state, and only animates while its slide is on
screen:

```css
.berg__tip  { transform: translateY(80px); opacity: 0; }        /* start state  */
.slide[data-active="true"] .berg__tip {
  animation: rise 1.1s cubic-bezier(.22,1,.36,1) 1.4s forwards; /* play + hold  */
}
@keyframes rise { from { transform: translateY(60px); opacity: 0 } to { transform: none; opacity: 1 } }
```

Because the selector is scoped to `data-active="true"`, the animation replays every time the
presenter comes back to the slide. `forwards` holds the final frame so a screenshot mid-talk is never
half-drawn.

## Choreography: entrance beats, then ambience

Chain the beats with `animation-delay`, in a spoken rhythm of roughly 300 ms per idea:

| Beat | Delay | Element |
|---|---|---|
| the ship sails in | 1.1s | `shipIn` translateX |
| the visible tip rises | 1.4s | `rise` |
| the hidden mass rises | 2.0s | `rise`, slower easing |
| the labels land | 2.6s → 3.9s | `fadeIn`, 300 ms apart |
| the total pops | 4.4s | `pop` |

Then hand over to **ambient loops** that never stop, so a slide left on screen during Q&A still feels
alive but never distracts: `bob` (the ship, 3.6s), `wake` (opacity pulse, 2.4s), `bubble` (rising
circles, 6s with a per-element `--d` delay).

Two easings cover everything: `cubic-bezier(.22,1,.36,1)` for anything that arrives (fast then
settles), and `ease-in-out` for anything that breathes.

## Drawing the scene

- **`<linearGradient>` for depth.** Three stops on water (light at the surface, near-black at the
  bottom) reads as depth; two stops reads as a flat rectangle.
- **`<clipPath>` for a horizon.** One clip above the waterline, one below, so a single shape can be
  half in the air and half underwater without drawing it twice.
- **Contrast between the object and its medium.** The first iceberg failed review because the ice and
  the sea shared a blue. Fix: bright ice gradient plus a white stroke against a dark sea.
- **Per-element custom properties** for staggering: `style="--d: 1.4s"` on each bubble, read by the
  keyframe delay. No extra CSS classes.

## QA rules for animated slides

1. Add the slide to `scripts/qa_overflow.py`'s `QA_WAIT` with the **full duration** (entrance beats +
   a beat), or the screenshot catches the scene mid-rise and the audit reports false overflow.
2. Check the longest locale (usually ES) for text that runs past its panel.
3. Run `scripts/audit_arrows.py`: connectors that move can end up over a label only in the final frame.
4. Respect the room: nothing should blink or move faster than ~2 Hz.

## Other scenes worth building this way

The same skeleton (gradient background, clip horizon, entrance beats, ambient loop, HTML overlay)
covers: a pipeline filling left to right, a queue draining, a relay handoff between agents, a meter
needle settling on a number, a stack of layers assembling. Draw the rest state first, then decide
which three things move.
