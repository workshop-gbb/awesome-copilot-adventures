"""qa_deck v3.0.0: overflow and error gate for every slide in the three locales.
Usage: python qa_deck.py deck.html [en,pt-BR,es]
Fails a slide on scrollHeight > 721, on any element wider than its box (code, terminals and mocks
with internal scroll excluded), and on any box crossing the right or bottom edge of the stage.
Measures with animations off (.ps-measure, pseudo-elements included). Exit code 1 when anything is bad."""
import asyncio, sys, os
from playwright.async_api import async_playwright
F = os.path.abspath(sys.argv[1]); LOCS = sys.argv[2].split(',') if len(sys.argv) > 2 else ['en', 'pt-BR', 'es']
CHECK = """()=>{const s=document.querySelector('.slide[data-active=true]'); s.classList.add('ps-measure');
  const R=s.getBoundingClientRect(); let bad=null; const k=s.dataset.psk||'-';
  if(s.scrollHeight>721) bad='sh '+s.scrollHeight;
  for(const e of s.querySelectorAll('*')){ if(bad) break; if(e.closest('.code-block, .gterm, pre, .kbd-hint, .deco, .term, .vsc, .chatwin, .portal, .ghpr, .browser, .phone, .gantt__t, [data-nofit]')) continue;
    const r=e.getBoundingClientRect(); if(!r.width) continue;
    const cs=getComputedStyle(e);
    if(e.scrollWidth>e.clientWidth+1 && cs.overflowX!=='auto' && !e.closest('svg')) bad='sw '+e.className+' '+(e.textContent||'').trim().slice(0,30);
    // CLIP: a framed box (border or paper background) that hides part of its own content
    else if(!e.closest('svg') && cs.overflow!=='visible' && e.scrollHeight>e.clientHeight+2 && cs.overflowY!=='auto'
            && (parseFloat(cs.borderTopWidth)>0 || parseFloat(cs.borderLeftWidth)>0 || !/rgba\(0, 0, 0, 0\)|transparent/.test(cs.backgroundColor)))
      bad='clip '+e.className+' '+e.scrollHeight+'>'+e.clientHeight+' '+(e.textContent||'').trim().slice(0,30);
    else if(r.right>R.right-39.5 || r.bottom>R.bottom+1 || r.left<R.left+20 || r.top<R.top-1) bad='rect '+e.tagName+'.'+e.className+' r='+Math.round(r.right)+' b='+Math.round(r.bottom)+' l='+Math.round(r.left)+' t='+Math.round(r.top);}
  s.classList.remove('ps-measure'); return [k,bad];}"""
async def main():
    total_bad = 0
    async with async_playwright() as p:
        b = await p.chromium.launch(); pg = await b.new_page(viewport={'width': 1280, 'height': 720}, reduced_motion='no-preference')
        errs = []; pg.on('pageerror', lambda e: errs.append(str(e)))
        await pg.goto('file://' + F); await pg.wait_for_timeout(1000)
        n = await pg.evaluate("document.querySelectorAll('.slide').length")
        for loc in LOCS:
            await pg.evaluate(f"setLocale('{loc}')"); await pg.wait_for_timeout(300)
            bad = []
            for i in range(n):
                await pg.evaluate(f'goToSlide({i})'); await pg.wait_for_timeout(420)
                r = await pg.evaluate(CHECK)
                if r[1]: bad.append((i + 1, r))
            print(loc, n, 'slides, bad:', len(bad)); [print('  slide', x[0], x[1]) for x in bad]; total_bad += len(bad)
        print('errors', errs[:10]); await b.close()
    sys.exit(1 if total_bad or errs else 0)
asyncio.run(main())
