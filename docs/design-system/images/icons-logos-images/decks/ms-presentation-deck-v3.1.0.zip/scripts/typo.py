"""typo v3.0.0: title and subtitle typography rules that every deck must follow.

1. Divider title fits in ONE line. Base 60px, shrinks per locale down to 41px; only if even that
   does not fit it falls back to two balanced lines at 48px.
2. Content title: base 56px. Tries one line down to 46px; otherwise two balanced lines at 56px.
3. No orphans, no lost breaks: function words (o, a, de, um, the, and, los, del ...) glue to the next
   word with NBSP and the last two words of a title or subtitle are glued. relaxNbsp() releases the
   glue if a chain ever overflows its box, so this never creates a horizontal overflow.
4. Build-time: the greedy NBSP chains from older decks (3 or 4 last words glued) are normalized to
   plain spaces, because a glued block wider than half the line produces exactly the broken
   "Faça o / agente terminar o trabalho." shape. The runtime rule above replaces them.

Usage in a build:  html = normalize_nbsp(html);  html = inject(html)
"""
import re

CSS = r"""
/* --- tipografia v3: divider em uma linha, titulo de conteudo em uma linha quando couber, sem orfas --- */
.section-title { font-size: 60px; line-height: 1.04; letter-spacing: -.03em; max-width: none; white-space: nowrap; margin: 0 0 18px; }
.section-number ~ .section-title { margin-top: 0; }
.section-number--bars { margin-bottom: 42px; }
.section-number ~ .subtitle, .slide--dark .section-title + .subtitle { font-size: 22px; line-height: 1.42; max-width: 1120px; }
.section-title[data-fitlines] { white-space: normal; }
.section-title[data-fitlines] span { display: block; white-space: nowrap; }
.title { font-size: 56px; line-height: 1.08; letter-spacing: -.025em; max-width: none; }
.title.title--medium { font-size: 40px; }
.title.title--small { font-size: 32px; }
.subtitle { max-width: none; font-size: 20px; }
.slide p, .slide li, .slide dd, .slide td, .slide figcaption, .subtitle, .lead, .tile__p, .lr__d, .why__p, .kpi__d, .card p { text-wrap: pretty; }
.title, .section-title, .tile__t, .kpi__l, .lr__t, .slide h2, .slide h3, .card h3 { text-wrap: balance; }
"""

JS = r"""
/* PS-TYPO v3: titulos em uma linha, sem orfas, sem quebra perdida. */
(function () {
  var SMALL = { the: 1, and: 1, for: 1, nor: 1, but: 1, los: 1, las: 1, del: 1, una: 1, que: 1, com: 1, por: 1, sem: 1, uma: 1, nos: 1, nas: 1, dos: 1, das: 1, aos: 1, sus: 1, sin: 1, con: 1, les: 1, des: 1, aux: 1, via: 1, per: 1 };
  var NB = String.fromCharCode(160);
  function isFn(w) { if (!/^[A-Za-zÀ-ɏ]{1,3}$/.test(w)) return false; return w.length <= 2 || !!SMALL[w.toLowerCase()]; }
  function glueNode(node) {
    var parts = node.nodeValue.split(' ');
    if (parts.length < 2) return;
    var out = parts[0];
    for (var i = 1; i < parts.length; i++) {
      var prev = parts[i - 1], cur = parts[i];
      out += (prev && cur && isFn(prev) ? NB : ' ') + cur;
    }
    node.nodeValue = out;
  }
  function textNodes(el) {
    var w = document.createTreeWalker(el, NodeFilter.SHOW_TEXT), n, a = [];
    while ((n = w.nextNode())) { if (n.parentElement && n.parentElement.closest('pre, code, svg, .gterm, .code-block')) continue; if (/\S/.test(n.nodeValue)) a.push(n); }
    return a;
  }
  function glue(el) {
    var nodes = textNodes(el); if (!nodes.length) return;
    var words = 0; nodes.forEach(function (n) { words += n.nodeValue.trim().split(/\s+/).length; });
    nodes.forEach(glueNode);
    if (words < 3) return;
    for (var i = nodes.length - 1; i >= 0; i--) {
      var v = nodes[i].nodeValue, m = v.replace(/\s+$/, ''), j = m.lastIndexOf(' ');
      if (j > 0) { nodes[i].nodeValue = m.slice(0, j) + NB + m.slice(j + 1) + v.slice(m.length); return; }
      if (m.indexOf(NB) >= 0) return;
    }
  }
  function fitOne(el, minRatio, twoLineScale) {
    el.style.fontSize = ''; el.style.whiteSpace = 'nowrap';
    var base = parseFloat(getComputedStyle(el).fontSize) || 0, W = el.clientWidth;
    if (!base || !W) { el.style.whiteSpace = ''; return; }
    var min = Math.max(Math.round(base * minRatio), Math.min(28, base));
    if (el.scrollWidth <= W + 1) return;
    var size = Math.max(min, Math.floor(base * W / el.scrollWidth));
    el.style.fontSize = size + 'px';
    var g = 0;
    while (el.scrollWidth > W + 1 && size > min && g++ < 40) { size -= 1; el.style.fontSize = size + 'px'; }
    if (el.scrollWidth > W + 1) { el.style.whiteSpace = ''; el.style.fontSize = twoLineScale ? Math.round(base * twoLineScale) + 'px' : ''; }
  }
  function skip(el) { return el.closest('.cover2') || el.hasAttribute('data-fitlines') || el.closest('[data-fitlines]'); }
  function psTypo() {
    var slide = document.querySelector('.slide[data-active="true"]'); if (!slide) return;
    slide.querySelectorAll('.section-title, .title, .subtitle, .lead, .hero-stmt, .tile__t, .kpi__l, .lr__t, .card h3').forEach(function (el) { if (el.closest('.cover2')) return; glue(el); });
    slide.querySelectorAll('.section-title').forEach(function (el) { if (skip(el)) return; fitOne(el, .68, .8); });
    slide.querySelectorAll('.title').forEach(function (el) { if (skip(el)) return; fitOne(el, .82, 0); });
    if (window.relaxNbsp) try { relaxNbsp(slide); } catch (e) {}
  }
  var prev = window.psFitAll;
  window.psFitAll = function () { if (prev) prev(); try { psTypo(); } catch (e) {} };
  window.psTypo = psTypo;
  if (document.readyState !== 'loading') { try { psTypo(); } catch (e) {} }
})();
"""

_PRE = re.compile(r'<pre[ >].*?</pre>', re.S)

def normalize_nbsp(html):
    """Replace raw NBSP characters by spaces everywhere except inside <pre> blocks."""
    out = []; pos = 0
    for m in _PRE.finditer(html):
        out.append(html[pos:m.start()].replace('\xa0', ' ')); out.append(m.group(0)); pos = m.end()
    out.append(html[pos:].replace('\xa0', ' '))
    return ''.join(out)

def inject(html):
    """Append the typography CSS + JS right before </body> (after every other layer)."""
    blk = '<style>' + CSS + '</style>\n<script>' + JS + '</script>\n'
    i = html.rindex('</body>')
    return html[:i] + blk + html[i:]

def apply(html):
    return inject(normalize_nbsp(html))
