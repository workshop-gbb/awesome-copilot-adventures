import asyncio, sys
from playwright.async_api import async_playwright
JS = """() => {
  const out = [];
  const slide = document.querySelector('.slide[data-active="true"]');
  slide.querySelectorAll('svg').forEach((svg, si) => {
    const texts = [...svg.querySelectorAll('text')].map(t => ({el: t, b: t.getBoundingClientRect(), s: t.textContent.trim().slice(0, 30)})).filter(t => t.b.width > 0);
    const conns = [...svg.querySelectorAll('path, line, polyline')].filter(e => (e.getAttribute('marker-end') || e.getAttribute('marker-start')) && getComputedStyle(e).display !== 'none');
    conns.forEach(c => {
      const len = c.getTotalLength ? c.getTotalLength() : 0; if (!len) return;
      const ctm = c.getScreenCTM();
      for (let d = 0; d <= len; d += 3) {
        const pt = c.getPointAtLength(d); const sp = new DOMPoint(pt.x, pt.y).matrixTransform(ctm);
        for (const t of texts) {
          if (sp.x > t.b.left + 1 && sp.x < t.b.right - 1 && sp.y > t.b.top + 2 && sp.y < t.b.bottom - 2) { out.push({svg: si, text: t.s, at: Math.round(d)}); break; }
        }
      }
    });
  });
  const seen = new Set(); return out.filter(o => { const k = o.svg + '|' + o.text; if (seen.has(k)) return false; seen.add(k); return true; });
}"""
async def main(locale):
    async with async_playwright() as p:
        br = await p.chromium.launch(); pg = await (await br.new_context(viewport={'width': 1280, 'height': 720})).new_page()
        await pg.goto('file://' + __import__('os').environ.get('DECK', '/mnt/user-data/outputs/deck.html')); await pg.wait_for_timeout(700)
        await pg.evaluate(f"setLocale('{locale}')"); n = await pg.evaluate("document.querySelectorAll('.slide').length")
        for i in range(n):
            await pg.evaluate(f"goToSlide({i})"); await pg.wait_for_timeout(1500)
            if i + 1 == 11:  # phases explorer: check every tab
                for k in range(5):
                    await pg.evaluate(f"document.querySelectorAll('.ph__tab')[{k}].click()"); await pg.wait_for_timeout(500)
                    for r in await pg.evaluate(JS): print(f"{i+1:02d} tab{k+1} svg{r['svg']} arrow crosses text: {r['text']!r}")
                continue
            for r in await pg.evaluate(JS): print(f"{i+1:02d} svg{r['svg']} arrow crosses text: {r['text']!r}")
        await br.close()
asyncio.run(main(sys.argv[1] if len(sys.argv) > 1 else 'pt-BR'))
