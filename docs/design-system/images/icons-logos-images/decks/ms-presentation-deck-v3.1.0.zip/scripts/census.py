"""census v3.0.0: archetype census. Classifies every slide by the component it really uses and prints
the distribution; exit 1 when one archetype passes 25 percent of the content slides.
Usage: python census.py deck.html [--list ARCHETYPE]"""
import re, sys, collections
h = open(sys.argv[1]).read()
secs = re.findall(r'<section class="slide[^>]*>.*?</section>', h, re.S)
FAM = [('cover2', 'COVER'), ('class="slide slide--light who', 'WHO'), ('section-number', 'DIVIDER'), ('class="agenda', 'AGENDA'), ('class="scene"', 'SCENE'),
       ('class="term"', 'TERMINAL'), ('class="vsc"', 'VSCODE'), ('class="chatwin"', 'CHAT'), ('class="portal"', 'PORTAL'), ('class="ghpr"', 'GITHUB'), ('class="browser"', 'BROWSER'), ('class="phone"', 'PHONE'),
       ('class="quiz"', 'QUIZ'), ('class="assess"', 'ASSESSMENT'), ('class="calc"', 'CALCULATOR'), ('class="toggle"', 'TOGGLE'), ('class="tabs"', 'TABS'), ('class="hot"', 'HOTSPOTS'), ('class="poll"', 'POLL'),
       ('class="dg"', 'DIAGRAM'), ('class="ch"', 'CHART'), ('class="hero-stmt"', 'HERO'), ('class="ledg"', 'LEDGER'), ('class="tiles', 'TILES'), ('class="kpis"', 'KPIS'), ('class="tline', 'TIMELINE'),
       ('class="bquote"', 'QUOTE'), ('class="checks"', 'CHECKLIST'), ('class="steps"', 'STEPS'), ('class="dodont"', 'DODONT'), ('class="defs"', 'DEFS'), ('class="gloss', 'GLOSSARY'), ('class="ptiers"', 'TIERS'),
       ('class="quad"', 'QUADRANT'), ('class="stats"', 'STATS'), ('class="pbars"', 'BARS'), ('class="ruler"', 'RULER'), ('class="gantt"', 'GANTT'), ('class="fig"', 'FIGURE'), ('class="vid"', 'VIDEO'), ('class="shapes"', 'SHAPES'),
       ('class="icongrid"', 'ICONS'), ('class="codewin"', 'CODE'), ('class="diff"', 'DIFF'), ('class="mdsrc"', 'MARKDOWN'), ('class="tree"', 'TREE'), ('class="linkcards', 'LINKS'), ('class="cmp"', 'COMPARE'), ('class="chips', 'CHIPS'),
       ('class="dt', 'TABLE'), ('class="grid-3', 'CARDS3'), ('class="card', 'CARDS'), ('class="code-block"', 'CODEBLOCK')]
def kind(s):
    for c, n in FAM:
        if c in s: return n
    return 'OTHER'
kinds = [kind(s) for s in secs]
if '--list' in sys.argv:
    want = sys.argv[sys.argv.index('--list') + 1]
    print([i + 1 for i, k in enumerate(kinds) if k == want]); sys.exit(0)
content = [k for k in kinds if k not in ('COVER', 'WHO', 'DIVIDER', 'AGENDA')]
c = collections.Counter(content); worst = 0
for k, n in c.most_common():
    pct = n / max(1, len(content)) * 100; worst = max(worst, pct)
    print(f'{k:12} {n:3}  {pct:5.1f}%')
print(f'{len(secs)} slides, {len(content)} content slides, {len(c)} archetypes')
sys.exit(1 if worst > 25 else 0)
